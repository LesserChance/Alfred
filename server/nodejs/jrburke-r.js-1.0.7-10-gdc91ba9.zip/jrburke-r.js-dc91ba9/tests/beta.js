define(['./sub/betaSub'], function (betaSub) {
    return {
        name: 'beta',
        subName: betaSub.name
    };
});
