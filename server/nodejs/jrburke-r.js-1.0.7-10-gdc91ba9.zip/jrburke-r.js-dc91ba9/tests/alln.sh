node allNode.js
node ../r.js all.js
