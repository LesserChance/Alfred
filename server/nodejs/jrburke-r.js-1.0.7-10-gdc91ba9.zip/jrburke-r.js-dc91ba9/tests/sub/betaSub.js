define({
    name: 'betaSubName'
});
