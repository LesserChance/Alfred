NowJS is hiring
===============

#Full Time

We're looking to hire employee #1 at NowJS. We're extremely picky. Experience designing distributed, scalable systems is a must. If you think you have the caliber to join us, shoot us an email.

#Interns

We're also hiring interns, flexible on the time period (summer, co-ops etc.).

###Preferred Skills:
- Node.js/Socket.io/NowJS experience
- Strong JavaScript background

###Benefits:
- Cool project
- Experienced, fun founders
- Great pay (free food/swag/monitors etc.)
- Weekly team events (kayaking, gokart, paintball etc)
- Beautiful office in Berkeley
- Rewarding, enjoyable summer
