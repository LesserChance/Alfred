Company
===============

Based in Berkeley, California, Flotype Inc. was founded by three UC Berkeley computer science dropouts. Funded by Silicon Valley's finest angels and VCs, Flotype has created NowJS, a technology that changes the client-server communication paradigm.

Led by a top-notch engineering and sales team, Flotype sells an enterprise-level, production ready version of NowJS that operates across a cluster of NowJS servers, scaling to hundreds of thousands of concurrent users.

For more information, email team@nowjs.com
